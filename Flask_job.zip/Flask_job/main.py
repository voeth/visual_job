from flask import Flask
from flask import request as req
from flask import render_template as render
from jinja2 import Markup, Environment, FileSystemLoader
from pyecharts.globals import CurrentConfig
import visualData as vd

# 关于 CurrentConfig，可参考 [基本使用-全局变量]
CurrentConfig.GLOBAL_ENV = Environment(loader=FileSystemLoader("./templates"))

from pyecharts import options as opts
from pyecharts.charts import Pie,Bar,Map,Tab

web = Flask(__name__)

@web.route("/")
def index():
    title = '欢迎进入求职宝，为您提供职位信息的可视化服务'
    return render('index.html',
              the_title=title)

@web.route("/visual",methods=['GET','POST'])
def visual():
    if req.method == 'POST':
        global keyword
        keyword = req.form['keyword']
        province = req.form['province']
        city =req.form['city']
        cityCode = vd.get_cityCode(province,city)
        data = vd.get_job(keyword,cityCode)
        if data:
            edu_data = vd.count_num(data,'education')
            sa_data= vd.divid_salary(vd.count_num(data,'salary'))
            ex_data = vd.count_num(data,'experience')

            edu_chart = vd.pie_chart(edu_data,keyword+'的学历要求统计','该学历要求的数量统计').render_embed()
            sa_chart = vd.bar_chart(sa_data,keyword+'的薪资水平统计','该薪资水平的数量统计',color='red').render_embed()
            ex_chart = vd.bar_chart(ex_data,keyword+'的工作经验统计',keyword+'的工作经验统计',color='black').render_embed()

            return render('visual.html',
                      edu_chart=Markup(edu_chart),
                       sa_chart=Markup(sa_chart),
                       ex_chart=Markup(ex_chart))
        else:
            hint = '输入的关键词有误！请输入有效的关键词'
    else:
        hint = '请输入关键词，使用post方法发起请求'
    return render('nothing.html',hint=hint)
    
@web.route("/map",methods=['GET','POST'])
def visual_map():
    if req.method == 'POST':
        data = vd.get_mapData(keyword)
        nation_map = vd.map_chart(data,'该岗位的需求数量：',keyword+'岗位需求').render_embed()
        return render('map.html',
                     the_map=Markup(nation_map))
    else:
        hint = '请输入关键词，在/visual 页面里，点击按钮查看此地图可视化。'
        return render('nothing.html',hint=hint)
if __name__ == '__main__':
    web.run(debug=True)
    